package com.otaliastudios.cameraview;

/**
 * Base interface for controls like {@link Audio},
 * {@link Facing}, {@link Flash} and so on.
 */
public interface Control {
}
