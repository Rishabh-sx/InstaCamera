package com.otaliastudios.cameraview;

@interface EncoderThread {}
